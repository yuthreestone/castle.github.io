# Listing_8-3.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# print the 8 times table 

for looper in [1, 2, 3, 4, 5]:
    print looper, "times 8 =", looper * 8