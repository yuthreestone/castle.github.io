# Listing_8-4.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# a loop using range()

for looper in range (1, 5):
    print looper, "times 8 =", looper * 8