# TIO_CH21_1.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# Print name, age, and favorite color in one sentence

name = raw_input("What is your name? ")
age = int(raw_input("How old are you? "))
color = raw_input("What is your favorite color? ")

print "Your name is", name,
print "you are ", age, "years old,",
print "and you like the color", color