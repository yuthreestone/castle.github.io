# TIO_CH15_4.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------


import random, time
for i in range(10):
    print random.random()
    time.sleep(3)
