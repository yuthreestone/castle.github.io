# Listing_13-3
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# Function with two arguments

def printMyAddress(someName, houseNum):    
    print someName                         
    print houseNum,                    
    print "Main Street"           
    print "Ottawa, Ontario"          
    print "K2M 2E9"                   
    print "Canada"                    
    print                             
    
printMyAddress("Carter Sande", "45")   # pass 2 arguments to the function
printMyAddress("Jack Black", "64")     
printMyAddress("Tom Green", "22")      
printMyAddress("Todd White", "36")     