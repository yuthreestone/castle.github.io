# Listing_8-1.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# A very simple for looop

for looper in [1, 2, 3, 4, 5]:
    print "hello"