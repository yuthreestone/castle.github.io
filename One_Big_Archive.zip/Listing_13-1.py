# Listing_13-1
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# Creating and using a function

# Define a function
def printMyAddress():                 
    print "Warren Sande"              
    print "123 Main Street"           
    print "Ottawa, Ontario"           
    print "K2M 2E9"                   
    print "Canada"                    
    print                             
    
# main program starts here - call the function
printMyAddress()                