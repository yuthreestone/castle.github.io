# Listing_5-1.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# Using raw_input

print "Enter your name: "
someName = raw_input()
print "Hi", someName, "how are you today?"
