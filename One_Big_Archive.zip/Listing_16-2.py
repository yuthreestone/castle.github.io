# Listing_16-2
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# Keeping the Pygame window open
# NOTE:  This program can only be stopped with 
#          CTRL-Break (for windows).

import pygame
pygame.init()
screen = pygame.display.set_mode([640, 480])
while True:               # this makes an endless loop
    pass
    
