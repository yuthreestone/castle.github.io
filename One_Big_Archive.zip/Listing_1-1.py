# Listing_1-1.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# Our first program

print "I love pizza!"
print "pizza " * 20
print "yum " * 40
print "I'm full."
