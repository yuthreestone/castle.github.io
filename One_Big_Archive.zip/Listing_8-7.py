# Listing_8-7.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# Who's the coolest?

for cool_guy in ["Spongebob", "Spiderman", "Justin Timberlake", "My dad"]:
    print cool_guy, "is the coolest guy ever!"