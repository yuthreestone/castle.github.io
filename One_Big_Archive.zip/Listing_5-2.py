# Listing_5-2.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# Putting strings together using commas

print "My",
print "name",
print "is",
print "Dave."