# Listing_21.1.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

#  Python program to print a table of squares and cubes
print "Number \tSquare \tCube"
for i in range (1, 11):
    print i, '\t', i**2, '\t', i**3 
