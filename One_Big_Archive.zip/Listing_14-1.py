# Listing_14-1.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# create a simple Ball class

# create a simple Ball class
class Ball:                             
                
    def bounce(self):                   # This is a method
        if self.direction == "down":    #
            self.direction = "up"       #