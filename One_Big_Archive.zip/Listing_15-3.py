# Listing_15-3.py
# Copyright Warren Sande, 2009
# Released under MIT license   http://www.opensource.org/licenses/mit-license.php
# Version 61  ----------------------------

# Putting your program to sleep

import time

print "How",
time.sleep(2)
print "are", 
time.sleep(2)
print "you",
time.sleep(2)
print "today?"